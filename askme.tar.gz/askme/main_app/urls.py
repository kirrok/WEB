from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^base/', views.base, name='base'),
    url(r'^hot/', views.hot, name='hot'),
    url(r'^tag/(?P<tag>[\w\-]+)/$', views.tag, name='tag'),
    url(r'^question/(\d+)/$', views.question, name='question'),
    url(r'^login/', views.login, name='login'),
    url(r'^signup/', views.signup, name='signup'),
    url(r'^ask/', views.ask, name='ask'),
    url(r'^$', views.index, name='index'),
]
