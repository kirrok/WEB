from django.shortcuts import render
from django.http import HttpResponse
from random import randint

questions = []
for i in xrange(0, 7):
    questions.append({
        'title': 'title_' + str(i),
        'id': i,
        'text': 'text_' + str(i),
        'answers': [{'text': 'text_' + str(j), 'likes': randint(0, 15)} for j in xrange(1, randint(5, 10))],
        'likes': randint(1, 30),
        'tags': ['tag_' + str(t) for t in xrange(1, randint(1, 7))]
    })

popular_tags = ['tag_' + str(i) for i in xrange(1, 10)]
best_members = ['member_' + str(i) for i in xrange(1, 10)]

tag = 'how to use django?'

user_yes = {
    'login': True,
}

user_no = {
    'login': False,
}


def base(request):
    return render(request, 'base.html')


def index(request):
    return render(request, 'index.html', {'questions': questions, 'user': user_no})


def hot(request):
    # hot questions...
    return render(request, 'hot.html',
                  {'questions': questions, 'popular_tags': popular_tags, 'best_members': best_members,
                   'user': user_yes})


def tag(request, tag):
    # questions by tag
    return render(request, 'tag.html', {'questions': questions, 'tag': tag, 'user': user_yes})


def question(request, id):
    # selection question by id ..
    return render(request, 'question.html', {'question': questions[int(id)], 'user': user_yes})


def login(request):
    return render(request, 'login.html', {'user': user_no})


def signup(request):
    return render(request, 'signup.html', {'user': user_no})


def ask(request):
    return render(request, 'ask.html', {'user': user_yes})

def paginate(objects_list, request):
        